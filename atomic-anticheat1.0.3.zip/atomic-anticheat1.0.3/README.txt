 _________________________________
|                                 |
|        Atomic Anti-Cheat        |
|        By Atomic Studios        |
|             v1.0.3              |
|_________________________________|

If you're gonna steal code or something, at least credit us.

discord.gg/uGUf34GFn7
